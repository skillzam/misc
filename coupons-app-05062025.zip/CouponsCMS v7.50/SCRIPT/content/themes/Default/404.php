<div class="container pt50 pb50">

<div class="row pt50">

    <div class="col-md-12 text-center title">
        <h1><?php te( 'theme_error_404', 'ERROR 404' ); ?></h1>
    </div>

</div>

<div class="row pb50">

    <div class="col-md-12 text-center">
        <h3><?php te( 'theme_error_404_msg', "This page you are looking for can't be found." ); ?></h3>
    </div>

</div>

</div>