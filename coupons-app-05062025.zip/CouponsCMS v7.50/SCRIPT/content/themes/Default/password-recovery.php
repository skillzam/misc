<div class="container pt50 pb50">

<div class="row">

    <div class="col-md-12 text-center title">
        <h2><?php te( 'theme_password_recovery_title', 'Password Recovery' ); ?></h2>
    </div>

</div>

<div class="row pt50 pb50">

    <div class="col-md-8 offset-md-2">
        <?php echo forgot_password_form(); ?>
    </div>

</div>

</div>