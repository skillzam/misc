-- --------------------------------------------------------

--
-- Structura de tabel pentru tabelul `banned`
--

CREATE TABLE `banned` (
  `id` int(100) NOT NULL,
  `ipaddr` varchar(50) NOT NULL DEFAULT '',
  `registration` tinyint(1) NOT NULL DEFAULT '0',
  `login` tinyint(1) NOT NULL DEFAULT '0',
  `site` tinyint(1) NOT NULL DEFAULT '0',
  `redirect_to` varchar(255) NOT NULL DEFAULT '',
  `expiration` tinyint(1) NOT NULL DEFAULT '0',
  `expiration_date` datetime NOT NULL DEFAULT '1970-01-01 00:00:00',
  `date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structura de tabel pentru tabelul `categories`
--

CREATE TABLE `categories` (
  `id` int(100) NOT NULL,
  `subcategory` int(10) NOT NULL DEFAULT '0',
  `user` int(10) NOT NULL DEFAULT '0',
  `name` text,
  `description` text,
  `url_title` varchar(255) NOT NULL DEFAULT '',
  `meta_title` varchar(255) NOT NULL DEFAULT '',
  `meta_keywords` text,
  `meta_desc` text,
  `extra` text,
  `date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Salvarea datelor din tabel `categories`
--

INSERT INTO `categories` (`id`, `subcategory`, `user`, `name`, `description`, `url_title`, `meta_title`, `meta_keywords`, `meta_desc`, `extra`, `date`) VALUES
(1, 0, 1, 'Example Category', NULL, '', '', NULL, NULL, NULL, '2019-01-26 16:19:09');

-- --------------------------------------------------------

--
-- Structura de tabel pentru tabelul `chat`
--

CREATE TABLE `chat` (
  `id` int(100) NOT NULL,
  `user` int(10) NOT NULL DEFAULT '0',
  `text` tinytext,
  `date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Salvarea datelor din tabel `chat`
--

INSERT INTO `chat` (`id`, `user`, `text`, `date`) VALUES
(1, 1, 'Hi there :) Welcome to your website !', '2019-01-26 16:19:09');

-- --------------------------------------------------------

--
-- Structura de tabel pentru tabelul `cities`
--

CREATE TABLE `cities` (
  `id` int(100) NOT NULL,
  `user` int(10) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `country` int(10) NOT NULL DEFAULT '0',
  `state` int(10) NOT NULL DEFAULT '0',
  `visible` tinyint(1) NOT NULL DEFAULT '1',
  `lat` double(20,14) NOT NULL,
  `lng` double(20,14) NOT NULL,
  `lastupdate_by` int(10) NOT NULL DEFAULT '0',
  `lastupdate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structura de tabel pentru tabelul `click`
--

CREATE TABLE `click` (
  `id` int(100) NOT NULL,
  `store` int(10) NOT NULL DEFAULT '0',
  `coupon` int(10) NOT NULL DEFAULT '0',
  `product` int(10) NOT NULL DEFAULT '0',
  `user` int(10) NOT NULL DEFAULT '0',
  `subid` varchar(50) NOT NULL DEFAULT '',
  `ipaddr` varchar(50) NOT NULL DEFAULT '',
  `browser` varchar(255) NOT NULL DEFAULT '',
  `country1` varchar(2) NOT NULL DEFAULT '',
  `country2` varchar(60) NOT NULL DEFAULT '',
  `date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structura de tabel pentru tabelul `countries`
--

CREATE TABLE `countries` (
  `id` int(100) NOT NULL,
  `user` int(10) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `visible` tinyint(1) NOT NULL DEFAULT '1',
  `lat` double(20,14) NOT NULL DEFAULT '0.00000000000000',
  `lng` double(20,14) NOT NULL DEFAULT '0.00000000000000',
  `lastupdate_by` int(10) NOT NULL DEFAULT '0',
  `lastupdate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structura de tabel pentru tabelul `coupons`
--

CREATE TABLE `coupons` (
  `id` int(100) NOT NULL,
  `feedID` int(10) NOT NULL DEFAULT '0',
  `user` int(10) NOT NULL DEFAULT '0',
  `store` int(10) NOT NULL DEFAULT '0',
  `category` int(10) NOT NULL DEFAULT '0',
  `popular` tinyint(1) NOT NULL DEFAULT '0',
  `exclusive` tinyint(1) NOT NULL DEFAULT '0',
  `printable` tinyint(1) NOT NULL DEFAULT '0',
  `show_in_store` tinyint(1) NOT NULL DEFAULT '0',
  `available_online` tinyint(1) NOT NULL DEFAULT '1',
  `title` text,
  `link` text,
  `description` text,
  `tags` text,
  `image` varchar(255) NOT NULL DEFAULT '',
  `code` varchar(255) NOT NULL DEFAULT '',
  `source` text,
  `claim_limit` int(10) NOT NULL DEFAULT '0',
  `claims` int(10) NOT NULL DEFAULT '0',
  `visible` tinyint(1) NOT NULL DEFAULT '1',
  `views` int(10) NOT NULL DEFAULT '0',
  `clicks` int(10) NOT NULL DEFAULT '0',
  `start` datetime NOT NULL DEFAULT '1970-01-01 00:00:00',
  `expiration` datetime NOT NULL DEFAULT '1970-01-01 00:00:00',
  `cashback` int(5) NOT NULL DEFAULT '0',
  `url_title` varchar(255) NOT NULL DEFAULT '',
  `meta_title` varchar(255) NOT NULL DEFAULT '',
  `meta_keywords` text,
  `meta_desc` text,
  `votes` int(10) NOT NULL DEFAULT '0',
  `votes_percent` double(7,2) NOT NULL DEFAULT '0.00',
  `verified` tinyint(1) NOT NULL DEFAULT '0',
  `last_verif` datetime NOT NULL DEFAULT '1970-01-01 00:00:00',
  `lastupdate_by` int(10) NOT NULL DEFAULT '0',
  `lastupdate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `paid_until` datetime NOT NULL DEFAULT '1970-01-01 00:00:00',
  `extra` text,
  `date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Salvarea datelor din tabel `coupons`
--

INSERT INTO `coupons` (`id`, `feedID`, `user`, `store`, `category`, `popular`, `exclusive`, `printable`, `show_in_store`, `available_online`, `title`, `link`, `description`, `tags`, `image`, `code`, `source`, `claim_limit`, `claims`, `visible`, `views`, `clicks`, `start`, `expiration`, `cashback`, `url_title`, `meta_title`, `meta_keywords`, `meta_desc`, `votes`, `votes_percent`, `verified`, `last_verif`, `lastupdate_by`, `lastupdate`, `paid_until`, `extra`, `date`) VALUES
(1, 0, 1, 1, 1, 0, 0, 0, 0, 1, 'Coupons Example !', NULL, 'This is just an example, you can delete it now !', NULL, '', '', NULL, 0, 0, 1, 0, 0, '2019-01-26 16:19:09', '2019-02-02 16:19:09', 0, '', '', NULL, NULL, 0, 0.00, 0, '1970-01-01 00:00:00', 0, '2019-01-26 16:19:09', '1970-01-01 00:00:00', '', '2019-01-26 16:19:09');

-- --------------------------------------------------------

--
-- Structura de tabel pentru tabelul `coupon_claims`
--

CREATE TABLE `coupon_claims` (
  `id` int(100) NOT NULL,
  `coupon` int(10) NOT NULL DEFAULT '0',
  `user` int(10) NOT NULL DEFAULT '0',
  `code` varchar(6) NOT NULL,
  `used` tinyint(1) NOT NULL DEFAULT '0',
  `used_date` datetime DEFAULT NULL,
  `date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structura de tabel pentru tabelul `coupon_votes`
--

CREATE TABLE `coupon_votes` (
  `id` int(100) NOT NULL,
  `coupon` int(10) NOT NULL DEFAULT '0',
  `user` int(10) NOT NULL DEFAULT '0',
  `vote` tinyint(1) NOT NULL DEFAULT '0',
  `ipaddr` varchar(50) NOT NULL DEFAULT '',
  `date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structura de tabel pentru tabelul `email_sessions`
--

CREATE TABLE `email_sessions` (
  `id` int(100) NOT NULL,
  `user` int(10) NOT NULL DEFAULT '0',
  `email` varchar(255) NOT NULL DEFAULT '',
  `target` varchar(50) NOT NULL DEFAULT '',
  `session` varchar(255) NOT NULL DEFAULT '',
  `expiration` datetime NOT NULL DEFAULT '1970-01-01 00:00:00',
  `date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structura de tabel pentru tabelul `favorite`
--

CREATE TABLE `favorite` (
  `id` int(100) NOT NULL,
  `user` int(10) NOT NULL DEFAULT '0',
  `store` int(10) NOT NULL DEFAULT '0',
  `date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structura de tabel pentru tabelul `gallery`
--

CREATE TABLE `gallery` (
  `id` int(100) NOT NULL,
  `user` int(10) NOT NULL DEFAULT '0',
  `title` varchar(50) NOT NULL DEFAULT '',
  `cat_id` varchar(50) NOT NULL DEFAULT '0',
  `sizes` text NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structura de tabel pentru tabelul `head`
--

CREATE TABLE `head` (
  `id` int(100) NOT NULL,
  `text` text,
  `admin` tinyint(1) NOT NULL DEFAULT '0',
  `theme` tinyint(1) NOT NULL DEFAULT '0',
  `plugin` varchar(255) NOT NULL DEFAULT '',
  `date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structura de tabel pentru tabelul `news`
--

CREATE TABLE `news` (
  `newsID` int(10) NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `url` varchar(255) NOT NULL DEFAULT '',
  `date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structura de tabel pentru tabelul `newsletter`
--

CREATE TABLE `newsletter` (
  `id` int(100) NOT NULL,
  `email` varchar(255) NOT NULL DEFAULT '',
  `ipaddr` varchar(50) NOT NULL DEFAULT '',
  `econf` tinyint(1) NOT NULL DEFAULT '0',
  `date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structura de tabel pentru tabelul `options`
--

CREATE TABLE `options` (
  `id` int(100) NOT NULL,
  `option_name` varchar(100) NOT NULL DEFAULT '',
  `option_value` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Salvarea datelor din tabel `options`
--

INSERT INTO `options` (`id`, `option_name`, `option_value`) VALUES
(1, 'sitename', 'Site Name'),
(2, 'sitetitle', 'Site Title'),
(3, 'meta_charset', 'UTF-8'),
(4, 'sitedescription', 'Welcome, this is my new website ! :)'),
(5, 'siteinstalled', '1548519549'),
(6, 'theme', 'Default'),
(7, 'items_per_page', '8'),
(8, 'delete_old_coupons', '0'),
(9, 'delete_old_products', '0'),
(10, 'default_user_avatar', 'avatar_aa.png'),
(11, 'default_store_avatar', 'store_avatar_aa.png'),
(12, 'default_reward_avatar', 'reward_avatar_aa.png'),
(13, 'meta_keywords', 'Meta Keywords'),
(14, 'meta_description', 'Meta Description'),
(15, 'registrations', 'opened'),
(16, 'accounts_per_ip', '3'),
(17, 'siteurl', ''),
(18, 'sitelang', 'english'),
(19, 'allow_select_lang', '1'),
(20, 'adminpanel_lang', 'english'),
(21, 'allow_reviews', '1'),
(22, 'review_validate', '1'),
(23, 'allow_stores', '1'),
(24, 'store_validate', '1'),
(25, 'allow_coupons', '1'),
(26, 'coupon_validate', '1'),
(27, 'allow_products', '1'),
(28, 'product_validate', '1'),
(29, 'timezone', 'UTC'),
(30, 'hour_format', '24'),
(31, 'u_def_points', '0'),
(32, 'u_points_review', '0'),
(33, 'u_points_davisit', '0'),
(34, 'u_points_refer', '0'),
(35, 'u_confirm_req', '0'),
(36, 'subscr_confirm_req', '0'),
(37, 'unsubscr_confirm_req', '0'),
(38, 'seo_link_store', 'store'),
(39, 'seo_link_coupon', 'coupon'),
(40, 'seo_link_product', 'product'),
(41, 'seo_link_category', 'category'),
(42, 'seo_link_reviews', 'reviews'),
(43, 'seo_link_stores', 'stores'),
(44, 'seo_link_search', 'search'),
(45, 'seo_link_user', 'user'),
(46, 'seo_link_plugin', 'plugin'),
(47, 'meta_store_title', '%NAME% | Site Title'),
(48, 'meta_store_keywords', 'Store keywords, ...'),
(49, 'meta_store_desc', 'Everything about %NAME%, list of coupons, deals and reviews from customers and users.'),
(50, 'meta_coupon_title', 'Coupon %NAME% | Site Title'),
(51, 'meta_coupon_keywords', 'Coupon keywords, ...'),
(52, 'meta_coupon_desc', 'Coupon %NAME% available for %STORE_NAME%, get it now !'),
(53, 'meta_product_title', 'Product %NAME% | Site Title'),
(54, 'meta_product_keywords', 'Product keywords, ...'),
(55, 'meta_product_desc', 'Product %NAME% available for %STORE_NAME%, get it now !'),
(56, 'meta_reviews_title', 'Reviews for %NAME% | Site Title'),
(57, 'meta_reviews_keywords', 'Store review keywords, ...'),
(58, 'meta_reviews_desc', 'Reviews for %NAME% received from customers and users !'),
(59, 'meta_category_title', '%NAME% | Site Title'),
(60, 'meta_category_keywords', 'Category keywords, ...'),
(61, 'meta_category_desc', 'Great coupons and deals for %NAME% !'),
(62, 'email_from_name', 'Your Name'),
(63, 'email_answer_to', 'answerto@yourdomain.ext'),
(64, 'email_contact', 'contact@yourdomain.ext'),
(65, 'facebook_appID', ''),
(66, 'facebook_secret', ''),
(67, 'google_clientID', ''),
(68, 'google_secret', ''),
(69, 'google_ruri', ''),
(70, 'paypal_mode', 'Sandbox'),
(71, 'paypal_ID', ''),
(72, 'paypal_secret', ''),
(73, 'google_maps_key', ''),
(74, 'price_store', '5'),
(75, 'price_coupon', '1'),
(76, 'price_max_days', '10'),
(77, 'price_product', '1'),
(78, 'price_product_max_days', '10'),
(79, 'feedserver', 'ggCoupon.com'),
(80, 'feedserver_auth', 'GET'),
(81, 'feedserver_ID', ''),
(82, 'feedserver_secret', ''),
(83, 'check_news', '0'),
(84, 'feed_uppics', '0'),
(85, 'feed_iexpc', '1'),
(86, 'feed_iexpp', '1'),
(87, 'feed_moddt', '1'),
(88, 'lfeed_check', '1548519549'),
(89, 'conf_unsubscr', '1'),
(90, 'mail_method', 'PHP Mail'),
(91, 'smtp_auth', '1'),
(92, 'smtp_host', 'tls://smtp.example.com'),
(93, 'smtp_port', '25'),
(94, 'smtp_user', ''),
(95, 'smtp_password', ''),
(96, 'sendmail', '/usr/bin/sendmail'),
(97, 'admintheme', 'theme/default.css'),
(98, 'cron_secret', '83fbbe04db31edc136897c160454c7c5'),
(99, 'mail_signature', ''),
(100, 'refer_cookie', '60'),
(101, 'social_facebook', ''),
(102, 'social_google', ''),
(103, 'social_twitter', ''),
(104, 'social_flickr', ''),
(105, 'social_linkedin', ''),
(106, 'social_vimeo', ''),
(107, 'social_youtube', ''),
(108, 'social_myspace', ''),
(109, 'social_reddit', ''),
(110, 'social_pinterest', ''),
(111, 'login_captcha', '0'),
(112, 'register_captcha', '0'),
(113, 'contact_captcha', '0'),
(114, 'suggest_captcha', '0'),
(115, 'subscribe_captcha', '0'),
(116, 'extension', '.html'),
(117, 'site_favicon', ''),
(118, 'site_logo', ''),
(119, 'site_indexfollow', '1'),
(120, 'allow_votes', '2'),
(121, 'delete_old_votes', '30'),
(122, 'smilies_coupons', '1'),
(123, 'smilies_products', '1'),
(124, 'smilies_stores', '1'),
(125, 'smilies_reviews', '1'),
(126, 'smilies_pages', '1'),
(127, 'smilies_categories', '1'),
(128, 'maintenance', '0'),
(129, 'google_maps_places', '1');

-- --------------------------------------------------------

--
-- Structura de tabel pentru tabelul `pages`
--

CREATE TABLE `pages` (
  `id` int(100) NOT NULL,
  `user` int(10) NOT NULL DEFAULT '0',
  `name` text,
  `text` text,
  `visible` tinyint(1) NOT NULL DEFAULT '0',
  `views` bigint(20) NOT NULL DEFAULT '0',
  `url_title` varchar(255) NOT NULL DEFAULT '',
  `meta_title` varchar(255) NOT NULL DEFAULT '',
  `meta_keywords` text,
  `meta_desc` text,
  `lastupdate_by` int(10) NOT NULL DEFAULT '0',
  `lastupdate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `extra` text,
  `date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Salvarea datelor din tabel `pages`
--

INSERT INTO `pages` (`id`, `user`, `name`, `text`, `visible`, `views`, `url_title`, `meta_title`, `meta_keywords`, `meta_desc`, `lastupdate_by`, `lastupdate`, `extra`, `date`) VALUES
(1, 1, 'About Us Page', 'Here will be something about us...', 1, 0, '', '', NULL, NULL, 1, '2019-01-26 16:19:09', NULL, '2019-01-26 16:19:09');

-- --------------------------------------------------------

--
-- Structura de tabel pentru tabelul `plugins`
--

CREATE TABLE `plugins` (
  `id` int(100) NOT NULL,
  `user` int(10) NOT NULL DEFAULT '0',
  `name` varchar(80) NOT NULL DEFAULT '',
  `image` varchar(255) NOT NULL DEFAULT '',
  `scope` varchar(60) NOT NULL DEFAULT '',
  `main` varchar(255) NOT NULL DEFAULT '',
  `loader` varchar(255) NOT NULL DEFAULT '',
  `options` varchar(255) NOT NULL DEFAULT '',
  `menu` tinyint(1) NOT NULL DEFAULT '0',
  `menu_ready` tinyint(1) NOT NULL DEFAULT '0',
  `menu_icon` int(2) NOT NULL DEFAULT '1',
  `subadmin_view` tinyint(1) NOT NULL DEFAULT '0',
  `extend_vars` text,
  `description` text,
  `visible` tinyint(1) NOT NULL DEFAULT '1',
  `version` double(6,2) NOT NULL DEFAULT '0.00',
  `update_checker` text,
  `uninstall` text,
  `date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structura de tabel pentru tabelul `products`
--

CREATE TABLE `products` (
  `id` int(100) NOT NULL,
  `feedID` int(10) NOT NULL DEFAULT '0',
  `user` int(10) NOT NULL DEFAULT '0',
  `store` int(10) NOT NULL DEFAULT '0',
  `category` int(10) NOT NULL DEFAULT '0',
  `popular` tinyint(1) NOT NULL DEFAULT '0',
  `title` text,
  `link` text,
  `description` text,
  `tags` text,
  `image` varchar(255) NOT NULL DEFAULT '',
  `price` double(15,2) NOT NULL DEFAULT '0.00',
  `old_price` double(15,2) NOT NULL DEFAULT '0.00',
  `currency` varchar(6) NOT NULL DEFAULT 'USD',
  `visible` tinyint(1) NOT NULL DEFAULT '0',
  `views` bigint(20) NOT NULL DEFAULT '0',
  `start` datetime NOT NULL DEFAULT '1970-01-01 00:00:00',
  `expiration` datetime NOT NULL DEFAULT '1970-01-01 00:00:00',
  `cashback` int(5) NOT NULL DEFAULT '0',
  `url_title` varchar(255) NOT NULL DEFAULT '',
  `meta_title` varchar(255) NOT NULL DEFAULT '',
  `meta_keywords` text,
  `meta_desc` text,
  `lastupdate_by` int(10) NOT NULL DEFAULT '0',
  `lastupdate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `paid_until` datetime NOT NULL DEFAULT '1970-01-01 00:00:00',
  `extra` text,
  `date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structura de tabel pentru tabelul `p_plans`
--

CREATE TABLE `p_plans` (
  `id` int(100) NOT NULL,
  `user` int(10) NOT NULL DEFAULT '0',
  `name` varchar(15) NOT NULL DEFAULT '',
  `description` text,
  `price` double(7,2) NOT NULL DEFAULT '0.00',
  `credits` int(5) NOT NULL DEFAULT '10',
  `image` varchar(255) NOT NULL DEFAULT '',
  `lastupdate_by` int(10) NOT NULL DEFAULT '0',
  `lastupdate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `visible` tinyint(1) NOT NULL DEFAULT '0',
  `date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structura de tabel pentru tabelul `p_transactions`
--

CREATE TABLE `p_transactions` (
  `id` int(100) NOT NULL,
  `user` int(10) NOT NULL DEFAULT '0',
  `gateway` varchar(30) NOT NULL DEFAULT '',
  `price` double(7,2) NOT NULL DEFAULT '0.00',
  `transaction_id` varchar(255) NOT NULL DEFAULT '',
  `state` varchar(30) NOT NULL DEFAULT '',
  `items` text,
  `details` text,
  `lastupdate_by` int(10) NOT NULL DEFAULT '0',
  `lastupdate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `visible` tinyint(1) NOT NULL DEFAULT '0',
  `paid` tinyint(1) NOT NULL DEFAULT '0',
  `delivered` tinyint(1) NOT NULL DEFAULT '0',
  `date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structura de tabel pentru tabelul `reviews`
--

CREATE TABLE `reviews` (
  `id` int(100) NOT NULL,
  `user` int(10) NOT NULL DEFAULT '0',
  `store` int(10) NOT NULL DEFAULT '0',
  `text` text,
  `stars` int(1) NOT NULL DEFAULT '5',
  `valid` tinyint(1) NOT NULL DEFAULT '0',
  `lastupdate_by` int(10) NOT NULL DEFAULT '0',
  `lastupdate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structura de tabel pentru tabelul `rewards`
--

CREATE TABLE `rewards` (
  `id` int(100) NOT NULL,
  `user` int(10) NOT NULL DEFAULT '0',
  `points` int(5) NOT NULL DEFAULT '0',
  `title` text,
  `description` text,
  `image` varchar(255) NOT NULL DEFAULT '',
  `fields` text,
  `lastupdate_by` int(10) NOT NULL DEFAULT '0',
  `lastupdate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `visible` tinyint(1) NOT NULL DEFAULT '0',
  `date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structura de tabel pentru tabelul `rewards_reqs`
--

CREATE TABLE `rewards_reqs` (
  `id` int(100) NOT NULL,
  `name` varchar(255) NOT NULL DEFAULT '',
  `user` int(10) NOT NULL DEFAULT '0',
  `points` int(5) NOT NULL DEFAULT '0',
  `reward` int(10) NOT NULL DEFAULT '0',
  `fields` text,
  `lastupdate_by` int(10) NOT NULL DEFAULT '0',
  `lastupdate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `claimed` tinyint(1) NOT NULL DEFAULT '0',
  `date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structura de tabel pentru tabelul `saved`
--

CREATE TABLE `saved` (
  `id` int(100) NOT NULL,
  `user` int(10) NOT NULL DEFAULT '0',
  `item` int(10) NOT NULL DEFAULT '0',
  `type` varchar(20) NOT NULL DEFAULT '',
  `date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structura de tabel pentru tabelul `sessions`
--

CREATE TABLE `sessions` (
  `id` int(100) NOT NULL,
  `user` int(10) NOT NULL DEFAULT '0',
  `session` varchar(255) NOT NULL DEFAULT '',
  `expiration` datetime NOT NULL,
  `date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structura de tabel pentru tabelul `states`
--

CREATE TABLE `states` (
  `id` int(100) NOT NULL,
  `user` int(10) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `country` int(10) NOT NULL DEFAULT '0',
  `visible` tinyint(1) NOT NULL DEFAULT '0',
  `lat` double(20,14) NOT NULL DEFAULT '0.00000000000000',
  `lng` double(20,14) NOT NULL DEFAULT '0.00000000000000',
  `lastupdate_by` int(10) NOT NULL DEFAULT '0',
  `lastupdate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structura de tabel pentru tabelul `stores`
--

CREATE TABLE `stores` (
  `id` int(100) NOT NULL,
  `feedID` int(10) NOT NULL DEFAULT '0',
  `user` int(10) NOT NULL DEFAULT '0',
  `category` int(10) NOT NULL DEFAULT '0',
  `popular` tinyint(1) NOT NULL DEFAULT '0',
  `physical` tinyint(1) NOT NULL DEFAULT '0',
  `name` text,
  `link` text,
  `description` text,
  `tags` text,
  `image` varchar(255) NOT NULL DEFAULT '',
  `hours` text,
  `phoneno` varchar(30) NOT NULL DEFAULT '',
  `sellonline` tinyint(1) NOT NULL DEFAULT '1',
  `visible` tinyint(1) NOT NULL DEFAULT '1',
  `views` bigint(20) NOT NULL DEFAULT '0',
  `url_title` varchar(255) NOT NULL DEFAULT '',
  `meta_title` varchar(255) NOT NULL DEFAULT '',
  `meta_keywords` text,
  `meta_desc` text,
  `lastupdate_by` int(10) NOT NULL DEFAULT '0',
  `lastupdate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `extra` text,
  `date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Salvarea datelor din tabel `stores`
--

INSERT INTO `stores` (`id`, `feedID`, `user`, `category`, `popular`, `physical`, `name`, `link`, `description`, `tags`, `image`, `hours`, `phoneno`, `sellonline`, `visible`, `views`, `url_title`, `meta_title`, `meta_keywords`, `meta_desc`, `lastupdate_by`, `lastupdate`, `extra`, `date`) VALUES
(1, 0, 1, 1, 0, 0, 'Brand/Store Example', 'http://couponscms.com', 'This is just an example, you can delete it now !', NULL, '', NULL, '', 1, 1, 0, '', '', NULL, NULL, 0, '2019-01-26 16:19:09', '', '2019-01-26 16:19:09');

-- --------------------------------------------------------

--
-- Structura de tabel pentru tabelul `store_locations`
--

CREATE TABLE `store_locations` (
  `id` int(100) NOT NULL,
  `user` int(10) NOT NULL DEFAULT '0',
  `store` int(10) NOT NULL DEFAULT '0',
  `country` varchar(255) NOT NULL DEFAULT '',
  `countryID` int(10) NOT NULL DEFAULT '0',
  `state` varchar(255) NOT NULL DEFAULT '',
  `stateID` int(10) NOT NULL DEFAULT '0',
  `city` varchar(255) NOT NULL DEFAULT '',
  `cityID` int(10) NOT NULL DEFAULT '0',
  `zip` varchar(15) NOT NULL DEFAULT '',
  `address` varchar(255) NOT NULL DEFAULT '',
  `lat` double(20,14) NOT NULL DEFAULT '0.00000000000000',
  `lng` double(20,14) NOT NULL DEFAULT '0.00000000000000',
  `point` point NOT NULL,
  `lastupdate_by` int(10) NOT NULL DEFAULT '0',
  `lastupdate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structura de tabel pentru tabelul `suggestions`
--

CREATE TABLE `suggestions` (
  `id` int(100) NOT NULL,
  `user` int(10) NOT NULL DEFAULT '0',
  `type` int(2) NOT NULL DEFAULT '1',
  `viewed` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `url` varchar(255) NOT NULL DEFAULT '',
  `description` text,
  `message` text,
  `date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structura de tabel pentru tabelul `users`
--

CREATE TABLE `users` (
  `id` int(100) NOT NULL,
  `name` varchar(255) NOT NULL DEFAULT '',
  `email` varchar(255) NOT NULL DEFAULT '',
  `password` varchar(255) NOT NULL DEFAULT '',
  `avatar` text,
  `points` bigint(20) NOT NULL DEFAULT '0',
  `credits` bigint(20) NOT NULL DEFAULT '0',
  `ipaddr` varchar(255) NOT NULL DEFAULT '',
  `privileges` int(1) NOT NULL DEFAULT '0',
  `erole` text,
  `subscriber` tinyint(1) NOT NULL DEFAULT '1',
  `last_login` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `last_action` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `visits` bigint(20) NOT NULL DEFAULT '0',
  `fail_attempts` int(10) NOT NULL DEFAULT '0',
  `valid` tinyint(1) NOT NULL DEFAULT '1',
  `ban` datetime NOT NULL DEFAULT '1970-01-01 00:00:00',
  `refid` int(10) NOT NULL DEFAULT '0',
  `extra` text,
  `date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Salvarea datelor din tabel `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `avatar`, `points`, `credits`, `ipaddr`, `privileges`, `erole`, `subscriber`, `last_login`, `last_action`, `visits`, `fail_attempts`, `valid`, `ban`, `refid`, `extra`, `date`) VALUES
(1, 'Admin', 'admin', '21232f297a57a5a743894a0e4a801fc3', NULL, 0, 0, '109.100.109.64', 2, NULL, 1, '2019-01-26 16:19:09', '2019-01-26 16:19:09', 0, 0, 1, '1970-01-01 00:00:00', 0, NULL, '2019-01-26 16:19:09');

-- --------------------------------------------------------

--
-- Structura de tabel pentru tabelul `widgets`
--

CREATE TABLE `widgets` (
  `id` int(100) NOT NULL,
  `user` int(10) NOT NULL DEFAULT '0',
  `theme` varchar(255) NOT NULL DEFAULT '',
  `widget_id` varchar(50) NOT NULL DEFAULT '',
  `sidebar` varchar(255) NOT NULL DEFAULT '',
  `location` varchar(255) NOT NULL DEFAULT '',
  `title` varchar(255) NOT NULL DEFAULT '',
  `stop` int(4) NOT NULL DEFAULT '5',
  `type` varchar(50) NOT NULL DEFAULT '',
  `orderby` varchar(50) NOT NULL DEFAULT '',
  `position` int(2) NOT NULL DEFAULT '1',
  `text` text,
  `extra` text,
  `html` tinyint(1) NOT NULL DEFAULT '0',
  `mobile_view` tinyint(1) NOT NULL DEFAULT '1',
  `last_update` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `banned`
--
ALTER TABLE `banned`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `ipaddr` (`ipaddr`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `chat`
--
ALTER TABLE `chat`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cities`
--
ALTER TABLE `cities`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `click`
--
ALTER TABLE `click`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `countries`
--
ALTER TABLE `countries`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `coupons`
--
ALTER TABLE `coupons`
  ADD PRIMARY KEY (`id`);
ALTER TABLE `coupons` ADD FULLTEXT KEY `title` (`title`);
ALTER TABLE `coupons` ADD FULLTEXT KEY `description` (`description`);
ALTER TABLE `coupons` ADD FULLTEXT KEY `tags` (`tags`);

--
-- Indexes for table `coupon_claims`
--
ALTER TABLE `coupon_claims`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `coupon_votes`
--
ALTER TABLE `coupon_votes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `email_sessions`
--
ALTER TABLE `email_sessions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `favorite`
--
ALTER TABLE `favorite`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `gallery`
--
ALTER TABLE `gallery`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `head`
--
ALTER TABLE `head`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `news`
--
ALTER TABLE `news`
  ADD PRIMARY KEY (`newsID`);

--
-- Indexes for table `newsletter`
--
ALTER TABLE `newsletter`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `options`
--
ALTER TABLE `options`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `option_name` (`option_name`);

--
-- Indexes for table `pages`
--
ALTER TABLE `pages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `plugins`
--
ALTER TABLE `plugins`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);
ALTER TABLE `products` ADD FULLTEXT KEY `title` (`title`);
ALTER TABLE `products` ADD FULLTEXT KEY `description` (`description`);
ALTER TABLE `products` ADD FULLTEXT KEY `tags` (`tags`);

--
-- Indexes for table `p_plans`
--
ALTER TABLE `p_plans`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `p_transactions`
--
ALTER TABLE `p_transactions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `reviews`
--
ALTER TABLE `reviews`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `rewards`
--
ALTER TABLE `rewards`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `rewards_reqs`
--
ALTER TABLE `rewards_reqs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `saved`
--
ALTER TABLE `saved`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sessions`
--
ALTER TABLE `sessions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `states`
--
ALTER TABLE `states`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `stores`
--
ALTER TABLE `stores`
  ADD PRIMARY KEY (`id`);
ALTER TABLE `stores` ADD FULLTEXT KEY `name` (`name`);
ALTER TABLE `stores` ADD FULLTEXT KEY `description` (`description`);
ALTER TABLE `stores` ADD FULLTEXT KEY `tags` (`tags`);

--
-- Indexes for table `store_locations`
--
ALTER TABLE `store_locations`
  ADD PRIMARY KEY (`id`);
ALTER TABLE `store_locations` ADD FULLTEXT KEY `country` (`country`);
ALTER TABLE `store_locations` ADD FULLTEXT KEY `state` (`state`);
ALTER TABLE `store_locations` ADD FULLTEXT KEY `city` (`city`);
ALTER TABLE `store_locations` ADD FULLTEXT KEY `zip` (`zip`);
ALTER TABLE `store_locations` ADD FULLTEXT KEY `address` (`address`);
ALTER TABLE `store_locations` ADD SPATIAL KEY `point` (`point`);

--
-- Indexes for table `suggestions`
--
ALTER TABLE `suggestions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `widgets`
--
ALTER TABLE `widgets`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `banned`
--
ALTER TABLE `banned`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `chat`
--
ALTER TABLE `chat`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `cities`
--
ALTER TABLE `cities`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `click`
--
ALTER TABLE `click`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `countries`
--
ALTER TABLE `countries`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `coupons`
--
ALTER TABLE `coupons`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `coupon_claims`
--
ALTER TABLE `coupon_claims`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `coupon_votes`
--
ALTER TABLE `coupon_votes`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `email_sessions`
--
ALTER TABLE `email_sessions`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `favorite`
--
ALTER TABLE `favorite`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `gallery`
--
ALTER TABLE `gallery`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `head`
--
ALTER TABLE `head`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `newsletter`
--
ALTER TABLE `newsletter`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `options`
--
ALTER TABLE `options`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=129;
--
-- AUTO_INCREMENT for table `pages`
--
ALTER TABLE `pages`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `plugins`
--
ALTER TABLE `plugins`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `p_plans`
--
ALTER TABLE `p_plans`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `p_transactions`
--
ALTER TABLE `p_transactions`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `reviews`
--
ALTER TABLE `reviews`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `rewards`
--
ALTER TABLE `rewards`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `rewards_reqs`
--
ALTER TABLE `rewards_reqs`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `saved`
--
ALTER TABLE `saved`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `sessions`
--
ALTER TABLE `sessions`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `states`
--
ALTER TABLE `states`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `stores`
--
ALTER TABLE `stores`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `store_locations`
--
ALTER TABLE `store_locations`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `suggestions`
--
ALTER TABLE `suggestions`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `widgets`
--
ALTER TABLE `widgets`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT;